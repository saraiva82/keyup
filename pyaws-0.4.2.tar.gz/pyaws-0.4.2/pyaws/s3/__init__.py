"""
Functionality utilising Amazon EC2 Service
"""
