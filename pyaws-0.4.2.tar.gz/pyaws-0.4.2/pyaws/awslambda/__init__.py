"""
Functional Utilities for AWS Lambda
"""

from pyaws.awslambda.lambda_utils import *
from pyaws.awslambda.env import read_env_variable
