"""
Functional Utilities for working with Amazon Web Services' Resource Tags
"""
from pyaws.tags.tag_utils import *
