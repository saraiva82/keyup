"""
Functionality utilising Amazon EC2 Service
"""
from pyaws.ec2.state import running_instances, stopped_instances
from pyaws.ec2.ec2_utils import *
