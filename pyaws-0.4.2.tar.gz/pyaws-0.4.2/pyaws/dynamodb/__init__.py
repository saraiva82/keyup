"""
Functional Utilities for Amazon DynamoDB Database Service
"""
from pyaws.dynamodb.dynamodb import DynamoDBReader
